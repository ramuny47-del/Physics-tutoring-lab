self.addEventListener('push', event => {
  let data = {};
  try { data = event.data ? event.data.json() : {}; } catch { data = { title: 'Physics Tutoring', body: event.data?.text() || '' }; }
  const title = data.title || 'Physics Tutoring';
  const options = {
    body: data.body || '',
    tag: data.tag || 'physics-tutoring',
    renotify: true,
    data: { url: data.url || '/' },
    vibrate: data.strong ? [300,140,300] : [220,140,220],
  };
  event.waitUntil(self.registration.showNotification(title, options));
});
self.addEventListener('notificationclick', event => {
  event.notification.close();
  const url = event.notification.data?.url || '/';
  event.waitUntil((async () => {
    const windows = await clients.matchAll({ type: 'window', includeUncontrolled: true });
    for (const w of windows) {
      if ('focus' in w) { await w.focus(); if ('navigate' in w) await w.navigate(url); return; }
    }
    if (clients.openWindow) await clients.openWindow(url);
  })());
});
