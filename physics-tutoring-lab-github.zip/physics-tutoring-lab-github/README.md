# Physics Tutoring Lab Management System

A web-based management system developed for a university physics drop-in tutoring lab. The application helps students request assistance and helps tutors and coordinators manage the room, tutoring queue, staffing, and lab activity.

## Features

- Student check-in and course selection
- Interactive room map and seat selection
- One-click help requests and live tutoring queue
- Optional requested-tutor selection
- Tutor and coordinator dashboards
- Tutor availability and helping-status tracking
- Coordinator assignment tools
- Role-based access for students, tutors, coordinators, and lead coordinators
- Push notifications for waiting students
- Student visit/help-time tracking and achievements
- Tutor and lab activity metrics
- Progressive Web App support

## Technology

- HTML, CSS, and JavaScript
- Supabase for authentication, database, realtime data, RPCs, and backend functions
- Service Worker / Web Push notifications
- Cloud deployment

## Why I Built It

The system was created to improve day-to-day operations in a physics tutoring lab. Instead of relying on students to physically signal for help and staff to manually keep track of requests, the application provides a shared view of who needs help, where they are sitting, what course they are working on, and which tutors are available.

## Configuration

This public portfolio copy intentionally does **not** contain the production Supabase project credentials. To run your own instance, replace the placeholders in `index.html` with your own Supabase project URL and publishable key and configure the required database schema, RPC functions, and Edge Functions.

## Security

Never commit a Supabase service-role key, private API key, password, or other server-side secret to this repository.

## Status

Built for real-world use in a university physics tutoring environment and iteratively improved based on tutor, coordinator, and student workflows.
